﻿// ---------------------------------------------------
 
 
//
 
// ---------------------------------------------------

using $safeprojectname$.Models;
using $safeprojectname$.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace $safeprojectname$.Repositories
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public ProductRepository(DbContext context) : base(context)
        { }

       // private ApplicationDbContext _appContext => (ApplicationDbContext)_context;
    }
}
