﻿// ---------------------------------------------------
 
 
//
 
// ---------------------------------------------------

using $safeprojectname$.Models;
using System;
using System.Linq;

namespace $safeprojectname$.Repositories.Interfaces
{
    public interface IOrdersRepository : IRepository<Order>
    {

    }
}
