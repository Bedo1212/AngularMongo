﻿// ---------------------------------------------------
 
 
//
 
// ---------------------------------------------------

using System;
using System.Linq;

namespace QuickMongo.ViewModels
{
    public class ClaimViewModel
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
